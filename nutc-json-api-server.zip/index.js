const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors')
const fs = require('fs');
const app = express();
const port = 3000;

// 啟用 CORS
app.use(cors());

app.use(bodyParser.json());

// User 資料結構
class User {
  constructor(userId, userName, userAccount, userGender, createTime) {
    this.userId = userId;
    this.userName = userName;
    this.userAccount = userAccount;
    this.userGender = userGender;
    this.createTime = createTime;
  }
}

// 讀取資料庫文件
const getUsers = () => {
  try {
    return JSON.parse(fs.readFileSync('users.json', 'utf8'));
  } catch (error) {
    return [];
  }
};

// 寫入資料庫文件
const saveUsers = (users) => {
  fs.writeFileSync('users.json', JSON.stringify(users, null, 2));
};

// CRUD API 實現
// 創建用戶
app.post('/users', (req, res) => {
  try {
    const users = getUsers();
    const newUser = new User(Date.now(), req.body.userName, req.body.userAccount, req.body.userGender, new Date().toISOString());
    users.push(newUser);
    saveUsers(users);
    res.json({ isSuccess: true, msg: "User created successfully", data: newUser });
  } catch (error) {
    res.json({ isSuccess: false, msg: "Error creating user", data: {} });
  }
});


// 獲取所有用戶
app.get('/users', (req, res) => {
  try {
    let users = getUsers();
    if (req.query.searchValue) {
      users = users.filter(u => u?.userName?.includes(req.query.searchValue));
    }
    res.json({ isSuccess: true, msg: "Users retrieved successfully", data: users });
  } catch (error) {
    res.json({ isSuccess: false, msg: "Error retrieving users", data: [] });
  }
});


// 獲取特定用戶
app.get('/users/:userId', (req, res) => {
  try {
    const users = getUsers();
    const user = users.find(u => u.userId == req.params.userId);
    if (user) {
      res.json({ isSuccess: true, msg: "User found", data: user });
    } else {
      res.json({ isSuccess: false, msg: "User not found", data: null });
    }
  } catch (error) {
    res.json({ isSuccess: false, msg: "Error finding user", data: null });
  }
});


// 更新用戶
app.put('/users/:userId', (req, res) => {
  try {
    let users = getUsers();
    let index = users.findIndex(u => u.userId == req.params.userId);
    if (index !== -1) {
      users[index] = { ...users[index], ...req.body, userId: users[index].userId};
      saveUsers(users);
      res.json({ isSuccess: true, msg: "User updated successfully", data: users[index] });
    } else {
      res.json({ isSuccess: false, msg: "User not found", data: {} });
    }
  } catch (error) {
    res.json({ isSuccess: false, msg: "Error updating user", data: {} });
  }
});


// 刪除用戶
app.delete('/users/:userId', (req, res) => {
  try {
    let users = getUsers();
    let filteredUsers = users.filter(u => u.userId != req.params.userId);
    if (users.length !== filteredUsers.length) {
      saveUsers(filteredUsers);
      res.json({ isSuccess: true, msg: "User deleted successfully", data: {} });
    } else {
      res.status(404).json({ isSuccess: false, msg: "User not found", data: {} });
    }
  } catch (error) {
    res.status(500).json({ isSuccess: false, msg: "Error deleting user", data: {} });
  }
});


app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
